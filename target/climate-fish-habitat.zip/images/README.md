Directory for images related to visualization
